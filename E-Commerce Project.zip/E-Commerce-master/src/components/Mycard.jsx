import React, { Component, Fragment } from "react";




class Mycard extends Component {
    render() {
        return (
            <Fragment>
                
                

                
</Fragment>


                )
            }
        }
        
export default Mycard;