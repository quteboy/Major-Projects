import React from "react";
import {render } from "react-dom";





//app
import App from "appRoot/App";





render(<App />,document.getElementById("app"));