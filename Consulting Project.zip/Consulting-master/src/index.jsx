import React from "react";
import {render} from "react-dom";

//-> App
import App from "appRoot/App";



render(<App />,document.getElementById("app"));
