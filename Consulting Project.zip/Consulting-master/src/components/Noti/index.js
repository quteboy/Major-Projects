import './index.css';
export { default } from './Noti';
