import './index.css';
export { default } from './Bottombar';
export { default as BottombarItem } from './BottombarItem';