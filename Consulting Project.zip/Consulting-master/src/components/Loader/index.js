import './index.css';
export { default } from './Loader';
