import React, { Fragment } from "react";

function ErrorView() {

  return (
    <Fragment>
      <h1>404 Error not found</h1>
    </Fragment>
  );
}
export default ErrorView;
